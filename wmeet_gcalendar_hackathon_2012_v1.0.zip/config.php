<?php
session_start();
mysql_connect('localhost','','')or die("Not good.");
mysql_select_db('wildmedi_google') or die ("Problems...");
?>
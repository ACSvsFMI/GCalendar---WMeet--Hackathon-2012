<?php
$consumer_key='google.wildmedia.ro';
$consumer_secret='EdS-KhrYqcpXrvdAJsEY_-e3';
$callback='http://google.wildmedia.ro/contacts_done.php';
$emails_count='500'; // max-results 
?>